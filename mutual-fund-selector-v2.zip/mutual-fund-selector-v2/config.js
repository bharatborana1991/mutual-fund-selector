// Simple config so you don't hardcode the endpoint in script.js
// Update this to your Vercel deployment URL
window.APP_CONFIG = {
  API_ENDPOINT: "https://YOUR-VERCEL-PROJECT.vercel.app/api/find-funds"
};
